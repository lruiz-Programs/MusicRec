'''
I PLEDGE MY HONOR THAT I HAVE ABIDED BY THE STEVENS HONOR SYSTEM
Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
11/27/2023
'''
#Creates global Output Variable
output = ''
#Loads global file
PREF_FILE = "musicreplus.txt"
#Create the file if it exists or not
file = open(PREF_FILE,'a')
file.close
#Creates Username
USER_NAME = ""

def loadUsers(fileName):
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    Load user is based off of the book and creates a Dict of the users given
    '''
    file = open(fileName, 'r')
    userDict = {}
    for line in file:
    #Read and parse a single linex
        [userName, bands] = line.strip().split(":")
        bandList = bands.split(",")
        bandList.sort()
        userDict[userName] = bandList
    file.close()
    return userDict

def checkUser(userMap,username):
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    checkUser simply checks if the given user is within the dictionary of users and will return if its true or not
    '''
    for person in userMap:
        if username == person:
            return True
    return False

def newUser(username):
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    New user works similar to enterPref but just adds a user to the bottom of the file
    '''
    newPref = input("Enter an artist that you like (Enter to finish):\n")
    prefs = []
    while newPref != "":
        prefs.append(newPref.strip().title())
        newPref = input("Enter an artist that you like (Enter to finish):\n")
    # Always keep the lists in sorted order for ease of
    #comparison
    prefs.sort()
    Line = username + ':' + (','.join(prefs))
    file = open(PREF_FILE,'a')
    file.write("\n" + Line)
    file.close()
    return 


def enterPref(username):
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    Uses a while loop to get a users input
    '''
    global USER_MAP
    global output
    newPref = input("Enter an artist that you like (Enter to finish):\n")
    prefs = []
    while newPref != "":
        prefs.append(newPref.strip().title())
        newPref = input("Enter an artist that you like (Enter to finish):\n")
        prefs.sort()
    saveUserPreferences(username,prefs,PREF_FILE)
    menu()


def saveUserPreferences(userName, prefs,fileName):
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman 
    Writes all of the user preferences to the file.
    Returns nothing. 
    '''
    global USER_MAP
    USER_MAP[userName] = prefs
    file = open(fileName,"w")
    file.close()
    file = open(fileName, "a")
    for user in USER_MAP:
        toSave = str(user) + ":" + ",".join(USER_MAP[user]) + "\n"
        file.write(toSave)
    file.close()
    return

def getRec(currUser, prefs):
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman 
    Gets recommendations for a user (currUser) based
    on the users in userMap (a dictionary)
    and the user's preferences in pref (a list).
    Returns a list of recommended artists. 
    '''
    priv_map = privMap()
    bestUser = findBestUser(currUser, prefs, priv_map)
    recommendations = drop(prefs, priv_map[bestUser])
    if recommendations == []:
        return "No recommendations available at this time."
    else:
        return recommendations

def findBestUser(currUser, prefs, userMap):
    ''' 
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    Find the user whose tastes are closest to the currentuser. Return the best user's name (a string) 
    '''
    users = userMap.keys()
    bestUser = None
    bestScore = -1
    for user in users:
        score = numMatches(prefs, userMap[user])
        if score > bestScore and currUser != user:
            bestScore = score
            bestUser = user
    return bestUser

def drop(list1, list2):
    ''' 
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    Return a new list that contains only the elements in
    list2 that were NOT in list1.
    '''
    list3 = []
    i = 0
    j = 0
    while i < len(list1) and j < len(list2):
        if list1[i] == list2[j]:
            i += 1
            j += 1
        elif list1[i] < list2[j]:
            i += 1
        else:
            list3.append(list2[j])
            j += 1
    return list3

def numMatches( list1, list2 ):
    ''' 
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    return the number of elements that match between
    two sorted lists 
    '''
    matches = 0
    i = 0
    j = 0
    while i < len(list1) and j < len(list2):
        if list1[i] == list2[j]:
            matches += 1
            i += 1
            j += 1  
        elif list1[i] < list2[j]:
            i += 1
        else:
            j += 1
        return matches

def privMap():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    privMap just creates a dict that removes all the private users
    '''
    global USER_MAP
    private_map = {}
    for x in USER_MAP:
        if '$' not in x:
            private_map[x] = USER_MAP[x]
    return private_map

def showPop():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    showPop works by the following steps 
    > Creates a dictionary of users that ignore the private users
    > Creates a dictionary that tallys how much there is of each song
    > Creats a list of the values of the tallys from biggest to smallest
    > Gets the songs that have those given values
    '''
    private_map = privMap()
    Songs = {}
    Values = []
    mostPop = []
    for Artists in private_map:
        for song in private_map[Artists]:
            if song in Songs:
                Songs[song] += 1
            else:
                Songs[song] = 1

    for Artists in Songs:
        if Songs[Artists] not in Values:
            Values = Values + [Songs[Artists]]
    Values.sort(reverse=True)
    
    for likes in Values:
        for Artists in Songs:
            if Songs[Artists] == likes:
                if len(mostPop) >= 3:
                    break
                mostPop = mostPop + [Artists]
    return mostPop[0] + "\n" + mostPop[1] + "\n" + mostPop[2]


def howPop():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    howPop does the following
    > Creates a dict of all the users except the private ones
    > Gets the values of all the songs
    > Give back the highest value
    '''
    private_map = privMap()
    Songs = {}
    Values = []
    for Artists in private_map:
        for song in private_map[Artists]:
            if song in Songs:
                Songs[song] += 1
            else:
                Songs[song] = 1

    for Artists in Songs:
        if Songs[Artists] not in Values:
            Values = Values + [Songs[Artists]]
    Values.sort(reverse=True)   

    if Values[0] == []:
        return "Sorry, no artists found."
    elif Values[0] == 0:
        return "Sorry, no artists found."
    else:
        return (Values[0])


def mostLike():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    > Creates a private map of the user
    > Checks each of the lengths of the users preference list
    > Returns back the biggest length
    '''
    priv_map = privMap()
    mostUser = ""
    Likes = 0
    for x in priv_map:
        if Likes < len(priv_map[x]):
            Likes = len(priv_map[x])
    for x in priv_map:
        if Likes == len(priv_map[x]):
            mostUser += x + "\n"
    if mostUser == "":
        return "Sorry , no user found."
    else:
        return mostUser

        

def quitSave():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    This function just saves the code and exists the function
    '''
    print()

def Initiate():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    This is the initial part of the code which has two main objectives
    > Getting the username/Checking if they are in the Database
    > If they are in the username database it can start up the menu if they are not they will go into the new user setup
    '''
    global USER_MAP
    global USER_NAME
    USER_NAME = ''
    USER_NAME = input("Enter your name ( put a $ symbol after your name if you wish your preferences to remain private ):")

    #Checks if username is in the list of list names 
    if checkUser(USER_MAP,USER_NAME) == True:
        menu()
    else:
        newUser(USER_NAME)
        menu()
    
def menu():
    '''
    Made by: Benjamin Topolosky - Leighana Ruiz - Jackson Tullman
    The menu code has a few objectives
    >Generates the USER_MAP since it could have been changed during login this also gets re-updated every time
    it gets called again 
    >This also gets the users input to go to other parts of the program
    '''
    global USER_MAP
    global USER_NAME
    USER_MAP = loadUsers(PREF_FILE)
    global output
    output = ""
    #menu_options
    menu_options = ['e','r','p','h','m','q']
    while(output not in menu_options):
        output = input("Enter a letter to choose an option: \ne - Enter preferences\nr - Get recommendations\np = Show most popular artists\nh - How popular is the most popular\nm - Which user has the most likes\nq - Save and quit\n")
        match output:
            case 'e':
                enterPref(USER_NAME)
            case 'r':
                print(getRec(USER_NAME, USER_MAP[USER_NAME]))
                menu()
            case 'p':
                print(showPop())
                menu()
            case 'h':
                print(howPop())
                menu()          
            case 'm':
                print(mostLike())
                menu()
            case 'q':
                quitSave()

#Creates Global Usermap 
USER_MAP = loadUsers(PREF_FILE)
#Running the Start of the code
Initiate()